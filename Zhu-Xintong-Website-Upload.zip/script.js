const projects = {
  "poetic-cinema": {
    type: "WRITING / ACADEMIC PAPER",
    title: "中国诗性电影与传统美学的对话",
    lead: "从意象、抒情与文化认同三个层面，讨论诗性电影如何将中国传统美学转化为银幕语言。",
    image: "assets/writing-poetic-cinema.jpg",
    paper: true,
    facts: [["类型", "毕业论文"], ["身份", "独立创作"], ["关键词", "诗性电影"], ["研究方向", "传统美学"]],
    body: "论文由“意象盛宴”“灵魂抚触”与“民族魂韵”三部分展开，分析清净与虚无的视听营造、散点与隐喻的叙事策略，以及诗性电影对集体文化想象的构建。"
  },
  huanxin: {
    type: "VIDEO / VARIETY SHOW",
    title: "焕新环游传",
    lead: "一次以民族文化为目的地的旅行真人秀实践，也是一场关于内容策划与现场协作的训练。",
    image: "assets/project-huanxin-page.jpg",
    paper: true,
    facts: [["平台", "腾讯视频"], ["身份", "实习导演"], ["类型", "旅行真人秀"], ["时长", "60 分钟 / 集"]],
    body: "节目邀请“焕新娘娘团”前往多个民族文化发源地，通过深度探访与游学体验采集地方文化符号。我参与点位策划和统筹工作，在真实现场中平衡内容表达与执行节奏。"
  },
  oasis: {
    type: "VIDEO / DOCUMENTARY",
    title: "15个人的“绿洲”",
    lead: "以纪实与采访记录青年教师跨越大漠、扎根且末的支教故事。",
    image: "assets/project-oasis-page.jpg",
    paper: true,
    facts: [["出品", "中国青年报・中青在线"], ["身份", "编辑"], ["类型", "新闻纪实"], ["时长", "7 分 56 秒"]],
    body: "2000 年，十五位青年教师抵达塔克拉玛干沙漠腹地的且末。此后二十余年，越来越多教师走向这里。影片以个体选择折射一代代青年人的支教接力。"
  },
  guangming: {
    type: "WRITING / JOURNALISM",
    title: "文化与社会议题采写",
    lead: "独立承担文化、社会领域的新闻采写任务，让选题深度与传播效率彼此支撑。",
    image: "assets/writing-guangming.jpg",
    paper: true,
    facts: [["平台", "光明日报・光明网"], ["身份", "实习记者"], ["内容", "新闻 / 专访"], ["方向", "文化与民生"]],
    body: "实习期间完成多篇新闻及专访稿件，内容涵盖传统文化保护、社会民生热点等方向。通过采访、资料梳理与结构化写作，持续提升主流媒体语境下的新闻实践能力。"
  },
  music: {
    type: "VIDEO / PORTRAIT FILM",
    title: "乐・乐",
    lead: "用红、黄、蓝三原色讲述音乐如何进入一个人的日常、追梦与自我确认。",
    image: "assets/project-music-page.jpg",
    paper: true,
    facts: [["类型", "原创个人宣传片"], ["身份", "导演・编剧"], ["时长", "55 秒"], ["色彩", "红 / 黄 / 蓝"]],
    body: "红色对应乐队中的归属感，黄色承载追梦过程中的沉淀，蓝色则指向音乐与生活的融合。短片用紧凑的色彩结构完成一段个人表达。"
  },
  rainbow: {
    type: "WRITING / SCREENPLAY",
    title: "斯人若彩虹",
    lead: "从一段十年恋爱长跑切入，在现实与幻觉之间呈现当代青年对情感的不同理解。",
    image: "assets/writing-rainbow.jpg",
    paper: true,
    facts: [["类型", "爱情短片剧本"], ["身份", "独立创作"], ["时长", "6 分钟"], ["创作时间", "2022 年春"]],
    body: "剧本从男生视角进入一段长期关系，让现实经验与主观幻觉交错发生。强烈的情感冲突之后，故事以留白收束，把最终的判断交还给观众。"
  },
  beijing: {
    type: "PHOTOGRAPHY / BEIJING",
    title: "城墙内外",
    lead: "故宫、景山与鼓楼西大街，是行走无数次后仍会重新发现的北京。",
    image: "assets/project-beijing-page.jpg",
    paper: true,
    facts: [["地点", "北京"], ["年份", "2021—2023"], ["器材", "Ricoh XF30"], ["器材", "iPhone 13"]],
    body: "儿化音从马路这头传到那头，糖葫芦的甜气、铜锅的热风和光影下的红色城墙，共同组成了这座城市的灵魂。"
  },
  "dream-eater": {
    type: "WRITING / FEATURE SCREENPLAY",
    title: "食梦者",
    lead: "当创作灵感被误认成外部馈赠，一个怀才不遇的评论员开始怀疑自己的成功。",
    image: "assets/writing-dream-eater.jpg",
    paper: true,
    facts: [["类型", "电影剧本"], ["身份", "团队主创"], ["时长", "120 分钟"], ["题材", "职场 / 人生"]],
    body: "纸媒评论员林深在生活重创后，从梦里获得灵感并意外爆火。长期的自卑使他相信成功源自梦境，而不是自己的能力；为了寻找梦，他逐渐走向歧途。"
  },
  closet: {
    type: "VIDEO / SHORT FILM",
    title: "The Closet",
    lead: "衣柜带来意外惊喜，也让欲望显露出它的代价。",
    image: "assets/project-closet-page.jpg",
    paper: true,
    facts: [["类型", "剧情短片"], ["身份", "导演"], ["色彩", "彩色"], ["时长", "3 分 47 秒"]],
    body: "一位女生偶然发现衣柜中的奥秘，却因为贪婪得到意料之外的结局。影片以有限空间和类型化情节完成一则短小的欲望寓言。"
  },
  nanjing: {
    type: "PHOTOGRAPHY / NANJING",
    title: "奔赴",
    lead: "颐和路的梧桐、随园的日常与秦淮河的夜色，构成南京安静而有力量的样子。",
    image: "assets/project-nanjing-page.jpg",
    paper: true,
    facts: [["地点", "南京"], ["年份", "2022—2023"], ["器材", "Ricoh XF30"], ["器材", "iPhone 13"]],
    body: "走在颐和路上，小心避开人群。柔和的阳光落在黄墙，满地梧桐沙沙作响。不从众但内心充盈——这是第七次抵达南京时留下的文字。"
  },
  theatre: {
    type: "VIDEO / SITCOM",
    title: "非凡剧团",
    lead: "以大学剧团为背景，从工作与情感两个角度观察校园生活。",
    image: "assets/project-theatre-page.jpg",
    paper: true,
    facts: [["类型", "情景喜剧"], ["身份", "摄影・导播"], ["时长", "14 分 41 秒"], ["制作", "集体创作"]],
    body: "项目由戏剧影视文学专业同学集体完成。我担任一组摄影与二组导播，并参与舞美设计和物资采购，完整经历多人协作下的影像生产流程。"
  },
  elsewhere: {
    type: "PHOTOGRAPHY / TRAVEL",
    title: "在别处",
    lead: "街道、屋顶、湖面。远行的意义，是看见每座城市不同的生活肌理。",
    image: "assets/project-elsewhere-page.jpg",
    paper: true,
    facts: [["地点", "拉萨 / 婺源 / 杭州"], ["年份", "2021—2022"], ["器材", "Canon 5D2"], ["器材", "Nikon D7500 / Sony α7 IV"]],
    body: "从八廓街的人群到婺源晒秋，再到西湖逆光里的船与飞鸟，镜头不追求统一的风格，而是尊重地方本身的节奏。"
  }
};

const menuButton = document.querySelector(".menu-toggle");
const navigation = document.querySelector(".site-nav");

menuButton?.addEventListener("click", () => {
  const isOpen = menuButton.getAttribute("aria-expanded") === "true";
  menuButton.setAttribute("aria-expanded", String(!isOpen));
  navigation.classList.toggle("is-open", !isOpen);
  document.body.style.overflow = isOpen ? "" : "hidden";
});

navigation?.querySelectorAll("a").forEach((link) => {
  link.addEventListener("click", () => {
    menuButton?.setAttribute("aria-expanded", "false");
    navigation.classList.remove("is-open");
    document.body.style.overflow = "";
  });
});

const progressBar = document.querySelector(".reading-progress span");
const updateProgress = () => {
  const height = document.documentElement.scrollHeight - window.innerHeight;
  const percentage = height > 0 ? (window.scrollY / height) * 100 : 0;
  progressBar.style.width = `${percentage}%`;
};
window.addEventListener("scroll", updateProgress, { passive: true });
updateProgress();

document.querySelectorAll("[data-delay]").forEach((element) => {
  element.style.setProperty("--delay", `${element.dataset.delay}ms`);
});

const revealObserver = new IntersectionObserver((entries, observer) => {
  entries.forEach((entry) => {
    if (entry.isIntersecting) {
      entry.target.classList.add("is-visible");
      observer.unobserve(entry.target);
    }
  });
}, { threshold: 0.12, rootMargin: "0px 0px -45px" });

document.querySelectorAll(".reveal").forEach((element) => revealObserver.observe(element));

const filters = document.querySelectorAll(".filter");
const cards = document.querySelectorAll(".work-card");
filters.forEach((filter) => {
  filter.addEventListener("click", () => {
    const selected = filter.dataset.filter;
    filters.forEach((item) => {
      const active = item === filter;
      item.classList.toggle("is-active", active);
      item.setAttribute("aria-pressed", String(active));
    });
    cards.forEach((card) => {
      const visible = selected === "all" || card.dataset.category === selected;
      card.hidden = !visible;
    });
  });
});

const dialog = document.querySelector("#project-dialog");
const dialogImage = dialog.querySelector(".dialog-media img");
const dialogTitle = dialog.querySelector("#dialog-title");
const dialogType = dialog.querySelector(".dialog-type");
const dialogLead = dialog.querySelector(".dialog-lead");
const dialogFacts = dialog.querySelector(".dialog-facts");
const dialogBody = dialog.querySelector(".dialog-body");

const closeDialog = () => dialog.close();
dialog.querySelector(".dialog-close").addEventListener("click", closeDialog);
dialog.querySelector(".dialog-back").addEventListener("click", closeDialog);
dialog.addEventListener("click", (event) => {
  if (event.target === dialog) closeDialog();
});

cards.forEach((card) => {
  card.addEventListener("click", () => {
    const project = projects[card.dataset.project];
    if (!project) return;
    dialogImage.src = project.image;
    dialogImage.alt = project.title;
    dialogImage.classList.toggle("is-paper", Boolean(project.paper));
    dialogTitle.textContent = project.title;
    dialogType.textContent = project.type;
    dialogLead.textContent = project.lead;
    dialogBody.textContent = project.body;
    dialogFacts.replaceChildren(...project.facts.map(([term, detail]) => {
      const wrapper = document.createElement("div");
      const dt = document.createElement("dt");
      const dd = document.createElement("dd");
      dt.textContent = term;
      dd.textContent = detail;
      wrapper.append(dt, dd);
      return wrapper;
    }));
    dialog.showModal();
  });
});
